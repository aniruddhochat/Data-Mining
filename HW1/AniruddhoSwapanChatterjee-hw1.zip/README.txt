Note : All python code has been written in Google colab Jupyter Notebook
Problem 2
probabDist function consists of the main logic of the code.
functionFM basically calculated the formula based on the parameters maxDist and minDist.
It is taking time to execute for n=150000 and number of trails=10
Note: All the experiments and graphs have been generated using different values of n and number of trails = 10

Problem 5
Import the data set housingData.csv which is necessary for the python code to execute.


Files Attached
PDF - AniruddhoSwapanChatterjee-hw1-everything.pdf
Tex - AniruddhoSwapanChatterjee-hw1-everything.tex
Python - AniruddhoSwapanChatterjee-hw1.py
IPNYB - 
Data_Mining_HW1_Problem_2.ipnyb
Data_Mining_HW1_Problem_5.ipnyb